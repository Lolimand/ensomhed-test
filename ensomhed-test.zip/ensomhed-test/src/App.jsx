import React, { useState } from 'react';

const questions = [
  {
    question: "Når nogen virkelig ser dig, hvad sker der så indeni dig?",
    options: [
      "Jeg bliver bange for at de ser for meget",
      "Jeg føler mig forbundet, men også sårbar",
      "Jeg føler mig endelig eksisterende",
      "Jeg bliver i tvivl om hvem de ser",
    ],
    weights: [6, 1, 2, 0],
  },
  {
    question: "Hvis du skulle efterlade én sætning til verden, hvad ville den lyde som?",
    options: [
      "Glem mig ikke, selv hvis du aldrig så mig",
      "Jeg var her, men kun som din refleksion",
      "Mine ord overlevede mig",
      "Alt dette var en drøm jeg nægtede at vågne fra",
    ],
    weights: [0, 1, 2, 4],
  }
];

const results = [
  "Den Tavse Arkivar",
  "Spejlbarnet",
  "Den Forladte Fortæller",
  "Den Indre Ørken",
  "Skælvende Drømmer",
  "Den Halve Skygge",
  "Maskebæreren"
];

export default function App() {
  const [step, setStep] = useState(0);
  const [scores, setScores] = useState(Array(results.length).fill(0));
  const [result, setResult] = useState(null);

  const handleAnswer = (index) => {
    const newScores = [...scores];
    newScores[questions[step].weights[index]] += 1;
    setScores(newScores);
    if (step + 1 < questions.length) {
      setStep(step + 1);
    } else {
      const maxIndex = newScores.indexOf(Math.max(...newScores));
      setResult(results[maxIndex]);
    }
  };

  if (result !== null) {
    return <div className="result">Din arketype: {result}</div>;
  }

  return (
    <div>
      <h1>Hvilken form for ensomhed er du?</h1>
      <p>{questions[step].question}</p>
      {questions[step].options.map((opt, i) => (
        <button key={i} onClick={() => handleAnswer(i)}>{opt}</button>
      ))}
    </div>
  );
}